<!DOCTYPE html>
<html>
<head>
</head>
<body>
<p>
    <?php
    echo "Primera página web con PHP";
    ?>
</p>
</body>
</html>